# TM and TE Waves in Circular Waveguides
# Full Theory, Derivations, and Engineering Applications (with Diagrams)

## 1. Introduction
This document provides an in-depth explanation of **Transverse Magnetic (TM)** and **Transverse Electric (TE)** modes in **circular metallic waveguides**, used in microwave engineering, radar systems, and optical communications.

## 2. Physical Overview
A circular waveguide of radius \(a\) confines fields that satisfy Maxwell’s equations within a cylindrical geometry. The fields decompose into two main families:
- **TE (Transverse Electric)**: electric field has no longitudinal component (\(E_z = 0\)).
- **TM (Transverse Magnetic)**: magnetic field has no longitudinal component (\(H_z = 0\)).

---

## 6. Dispersion Diagram
![Dispersion Diagram](figures/dispersion_diagram.png)

## 9. Field Patterns Visualization
### TE₁₁ Mode Field Pattern
![TE11 Mode Field Pattern](figures/TE11_field.png)

### TM₀₁ Mode Field Pattern
![TM01 Mode Field Pattern](figures/TM01_field.png)

---

## 13. References
1. R. E. Collin, *Foundations for Microwave Engineering*, McGraw-Hill.
2. D. M. Pozar, *Microwave Engineering*, Wiley.
3. C. A. Balanis, *Advanced Engineering Electromagnetics*.
4. NIST Bessel Function Tables and SciPy documentation.
